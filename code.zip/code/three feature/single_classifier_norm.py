import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import VotingClassifier
#from sklearn.metrics import precision_score
from sklearn.model_selection import cross_val_score
#from sklearn.model_selection import ShuffleSplit
#from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_validate
from sklearn.preprocessing import MinMaxScaler

feature_list=['Hypersensitive c-reactive protein','Lactate dehydrogenase','(%)lymphocyte']

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')
testdata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_test_110_preprocess_en.xlsx")

features_train=traindata[:][feature_list]
#features_train.fillna(0,inplace=True)
for col in feature_list:
    #replace_val = 0.0
    #replace_val = traindata[col].mean()
    #replace_val = traindata[col].median()
    replace_val = traindata[col].mode().iloc[0]
    features_train[col].fillna(replace_val,inplace=True)

y=traindata[:]['outcome']
scaler = MinMaxScaler()
X_original = features_train.values.tolist()
X = scaler.fit_transform(X_original)
print(X_original[:10])
print(X[:10])
Y=y.values.tolist()

'''
features_test=testdata[:][feature_list]
features_test.fillna(0,inplace=True)
#features_test.fillna(testdata[f].mean(),inplace=True)
#features_test.fillna(testdata[f].median(),inplace=True)
#features_test.fillna(testdata[f].mode().iloc[0],inplace=True)
features_test=features_test.values.tolist()
target=testdata[:]['outcome']
'''
#eclf = VotingClassifier(estimators=[('knn1', knn3), ('dt', dt), ('gnb', gnb)],voting='hard')

def confusion_matrix_scorer(clf, X, y):
    y_pred = clf.predict(X)
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}

with open(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\results\three\norm\single_feature(mode).txt",'a',encoding='utf-8') as file:
    #file.write("feature\tmodel\tcorss_validation\tprecision_1\trecall_1\tf1_score_1\tprecision_0\trecall_0\tf1_score_0\taccuracy\n")
    file.write("\tfeature\tmodel\tf1_score_1\tf1_score_0\taccuracy\n")
    knn1 = KNeighborsClassifier(n_neighbors=3)
    knn2 = KNeighborsClassifier(n_neighbors=5)
    knn3 = KNeighborsClassifier(n_neighbors=7)
    svm_rbf = svm.SVC(kernel="rbf")
    svm_poly = svm.SVC(kernel="poly")
    svm_sigmoid = svm.SVC(kernel="sigmoid")
    gnb = GaussianNB()
    dt = tree.DecisionTreeClassifier()
    lg = LogisticRegression(solver='liblinear',penalty='l1')
    models=[knn1,knn2,knn3,svm_rbf,svm_poly,svm_sigmoid,gnb,dt,lg]
    for m in models:
        print(m)
        #score=cross_val_score(m,feature,labels,cv=5,scoring='accuracy')
        score=cross_validate(m,X,Y,cv=5,scoring=confusion_matrix_scorer)
        f1_1_sum=[]
        f1_0_sum=[]
        acc_sum=[]
        for i in range(5):
            recall_1= score['test_tp'][i]/(score['test_fn'][i]+score['test_tp'][i])
            precision_1 = score['test_tp'][i]/(score['test_fp'][i]+score['test_tp'][i])
            f1_1 = 2*recall_1*precision_1/(recall_1+precision_1)
            f1_1_sum.append(f1_1)
            recall_0= score['test_tn'][i]/(score['test_fp'][i]+score['test_tn'][i])
            precision_0 = score['test_tn'][i]/(score['test_fn'][i]+score['test_tn'][i])
            f1_0 = 2*recall_0*precision_0/(recall_0+precision_0)
            f1_0_sum.append(f1_0)
            acc = (score['test_tp'][i]+score['test_tn'][i])/(score['test_fn'][i]+score['test_tp'][i]+score['test_fp'][i]+score['test_tn'][i])
            acc_sum.append(acc)
            print(str(i)+"\t1: "+ str(precision_1)+"\t"+str(recall_1))
            print(str(i)+"\t0: "+ str(precision_0)+"\t"+str(recall_0))
            print("accuracy\t"+str())
            #file.write(str(feature_list)+"\t"+str(m)+"\t"+str(i)+"\t"+str(precision_1)+"\t"+str(recall_1)+"\t"+str(f1_1)+"\t"+str(precision_0)+"\t"+str(recall_0)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")
        file.write("average\t"+','.join(feature_list)+"\t"+str(m)+"\t"+str(np.mean(f1_1_sum))+"\t"+str(np.mean(f1_0_sum))+"\t"+str(np.mean(acc_sum))+"\n")
        #print(np.mean(score))
        #print(np.std(score)*2)
        print(score)
        #file.write(f+"\t"+str(m)+"\t"+str(np.mean(score))+"\t"+str(np.std(score)*2)+"\n")

