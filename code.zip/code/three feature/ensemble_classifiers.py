import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix

def confusion_matrix_scorer(y_pred, y):
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')
testdata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_test_110_preprocess_en.xlsx")

features_train=traindata[:][['Hypersensitive c-reactive protein','Lactate dehydrogenase','(%)lymphocyte']]
features_train.fillna(0,inplace=True)
y=traindata[:]['outcome']

features_test=testdata[:][['Hypersensitive c-reactive protein','Lactate dehydrogenase','(%)lymphocyte']]
features_test.fillna(0,inplace=True)
features_test=features_test.values.tolist()
target=testdata[:]['outcome']

X=features_train.values.tolist()
Y=y.values.tolist()

rf1 = RandomForestClassifier(n_estimators=5)
rf2 = RandomForestClassifier(n_estimators=10)
rf3 = RandomForestClassifier(n_estimators=15)
adaboost = AdaBoostClassifier(n_estimators=100)
xgboost = XGBClassifier(n_jobs=-1)
gbclf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,max_depth=1, random_state=0)

models=[rf1,rf2,rf3,adaboost,xgboost, gbclf]

for m in models:
    print(m)
    model=m.fit(X,Y)
    result=model.predict(features_test)
    score = confusion_matrix_scorer(result,target)
    print(score)
    recall_1= score['tp']/(score['fn']+score['tp'])
    precision_1 = score['tp']/(score['fp']+score['tp'])
    recall_0= score['tn']/(score['fp']+score['tn'])
    precision_0 = score['tn']/(score['fn']+score['tn'])
    print("1: "+ str(precision_1)+"\t"+str(recall_1))
    print("0: "+ str(precision_0)+"\t"+str(recall_0))
    #precision=precision_score(result,target)
    #print(precision)
