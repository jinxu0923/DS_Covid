import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import VotingClassifier
#from sklearn.metrics import precision_score
from sklearn.model_selection import cross_val_score
#from sklearn.model_selection import ShuffleSplit
#from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_validate
from sklearn.preprocessing import MinMaxScaler

feature_list=['Hypersensitive c-reactive protein','Lactate dehydrogenase','(%)lymphocyte']

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')
testdata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_test_110_preprocess_en.xlsx")

features_train=traindata[:][feature_list]
features_test=testdata[:][feature_list]

for col in feature_list:
    #replace_val = 0.0
    #replace_val = traindata[col].mean()
    #replace_val = traindata[col].median()
    replace_val_train = traindata[col].mode().iloc[0]
    replace_val_test = testdata[col].mode().iloc[0]
    features_train[col].fillna(replace_val_train,inplace=True)
    features_test[col].fillna(replace_val_test,inplace=True)

scaler = MinMaxScaler()

X_train=features_train.values.tolist()
X_train_norm = scaler.fit_transform(X_train)
y_train=traindata[:]['outcome']
Y_train=y_train.values.tolist()
print(X_train[:10])
print(X_train_norm[:10])
print("="*50)

features_test=features_test.values.tolist()
features_test_norm = scaler.transform(features_test)
y_test=testdata[:]['outcome']
Y_test=y_test.values.tolist()
print(features_test[:10])
print(features_test_norm[:10])


#eclf = VotingClassifier(estimators=[('knn1', knn3), ('dt', dt), ('gnb', gnb)],voting='hard')
'''
def confusion_matrix_scorer(clf, X, y):
    y_pred = clf.predict(X)
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}
'''

def confusion_matrix_scorer(y_pred, y):
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}

with open(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\results\three\train_test_norm.txt",'a',encoding='utf-8') as file:
    file.write("model\tf1_score_1\tf1_score_0\taccuracy\n")
    knn1 = KNeighborsClassifier(n_neighbors=3)
    knn2 = KNeighborsClassifier(n_neighbors=5)
    knn3 = KNeighborsClassifier(n_neighbors=7)
    svm_rbf = svm.SVC(kernel="rbf")
    svm_poly = svm.SVC(kernel="poly")
    svm_sigmoid = svm.SVC(kernel="sigmoid")
    gnb = GaussianNB()
    dt = tree.DecisionTreeClassifier()
    lg = LogisticRegression(solver='liblinear',penalty='l1')
    models=[knn1,knn2,knn3,svm_rbf,svm_poly,svm_sigmoid,gnb,dt,lg]
    for m in models:
        print(m)
        model=m.fit(X_train_norm,Y_train)
        result=model.predict(features_test_norm)
        score = confusion_matrix_scorer(result,Y_test)
        print(score)
        recall_1= score['tp']/(score['fn']+score['tp'])
        precision_1 = score['tp']/(score['fp']+score['tp'])
        f1_1 = 2*recall_1*precision_1/(recall_1+precision_1)
        recall_0= score['tn']/(score['fp']+score['tn'])
        precision_0 = score['tn']/(score['fn']+score['tn'])
        f1_0 = 2*recall_0*precision_0/(recall_0+precision_0)
        acc = (score['tp']+score['tn'])/(score['fn']+score['tp']+score['fp']+score['tn'])
        print("1: "+ str(precision_1)+"\t"+str(recall_1))
        print("0: "+ str(precision_0)+"\t"+str(recall_0))
        print("accuracy\t"+str(acc))
        #file.write(','.join(feature_list)+"\t"+str(m)+"\t"+str(precision_1)+"\t"+str(recall_1)+"\t"+str(f1_1)+"\t"+str(precision_0)+"\t"+str(recall_0)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")
        file.write(str(m)+"\t"+str(f1_1)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")

