import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import VotingClassifier
#from sklearn.metrics import precision_score
from sklearn.model_selection import cross_val_score
#from sklearn.model_selection import ShuffleSplit
#from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import cross_validate

feature_list=['Hypersensitive c-reactive protein','Lactate dehydrogenase','(%)lymphocyte']

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')
testdata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_test_110_preprocess_en.xlsx")

features_train=traindata[:][feature_list]
features_test=testdata[:][feature_list]

for col in feature_list:
    replace_val = 0.0
    #replace_val = traindata[col].mean()
    #replace_val = traindata[col].median()
    #replace_val_train = traindata[col].mode().iloc[0]
    #replace_val_test = testdata[col].mode().iloc[0]
    features_train[col].fillna(replace_val,inplace=True)
    features_test[col].fillna(replace_val,inplace=True)

X_train=features_train.values.tolist()
y_train=traindata[:]['outcome']
Y_train=y_train.values.tolist()

features_test=features_test.values.tolist()
y_test=testdata[:]['outcome']
Y_test=y_test.values.tolist()


#eclf = VotingClassifier(estimators=[('knn1', knn3), ('dt', dt), ('gnb', gnb)],voting='hard')
'''
def confusion_matrix_scorer(clf, X, y):
    y_pred = clf.predict(X)
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}
'''

def confusion_matrix_scorer(y_pred, y):
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}

with open(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\results\three\train_test1.txt",'a',encoding='utf-8') as file:
    file.write("model\tf1_score_1\tf1_score_0\taccuracy\n")
    rf1 = RandomForestClassifier(n_estimators=5)
    rf2 = RandomForestClassifier(n_estimators=10)
    rf3 = RandomForestClassifier(n_estimators=15)
    adaboost = AdaBoostClassifier(n_estimators=100)
    xgboost = XGBClassifier(n_jobs=-1)
    gbclf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,max_depth=1, random_state=0)
    models=[rf1,rf2,rf3,adaboost,xgboost, gbclf]
    for m in models:
        print(m)
        model=m.fit(X_train,Y_train)
        result=model.predict(features_test)
        score = confusion_matrix_scorer(result,Y_test)
        print(score)
        recall_1= score['tp']/(score['fn']+score['tp'])
        precision_1 = score['tp']/(score['fp']+score['tp'])
        f1_1 = 2*recall_1*precision_1/(recall_1+precision_1)
        recall_0= score['tn']/(score['fp']+score['tn'])
        precision_0 = score['tn']/(score['fn']+score['tn'])
        f1_0 = 2*recall_0*precision_0/(recall_0+precision_0)
        acc = (score['tp']+score['tn'])/(score['fn']+score['tp']+score['fp']+score['tn'])
        print("1: "+ str(precision_1)+"\t"+str(recall_1))
        print("0: "+ str(precision_0)+"\t"+str(recall_0))
        print("accuracy\t"+str(acc))
        #file.write(','.join(feature_list)+"\t"+str(m)+"\t"+str(precision_1)+"\t"+str(recall_1)+"\t"+str(f1_1)+"\t"+str(precision_0)+"\t"+str(recall_0)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")
        file.write(str(m)[:40]+"\t"+str(f1_1)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")

