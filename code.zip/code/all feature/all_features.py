import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import VotingClassifier
#from sklearn.metrics import precision_score
from sklearn.model_selection import cross_val_score

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')

labels = np.array(traindata['outcome'])
features= traindata.drop(['PATIENT_ID','RE_DATE','age','gender','Admission time','Discharge time','outcome'], axis = 1)
print(features.shape)

features.fillna(0,inplace=True)
features=features.values.tolist()

knn1 = KNeighborsClassifier(n_neighbors=3)
knn2 = KNeighborsClassifier(n_neighbors=5)
knn3 = KNeighborsClassifier(n_neighbors=7)
svms = svm.SVC()
gnb = GaussianNB()
dt = tree.DecisionTreeClassifier()
lg = LogisticRegression(solver='liblinear',penalty='l1')
#lg = LogisticRegression()
models=[knn1,knn2,knn3,svms,gnb,dt,lg]

for m in models:
    print(m)
    score=cross_val_score(m,features,labels,cv=5)
    print(np.mean(score))
    print(np.std(score)*2)
