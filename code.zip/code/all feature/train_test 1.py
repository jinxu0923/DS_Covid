import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import VotingClassifier
#from sklearn.metrics import precision_score
from sklearn.model_selection import cross_val_score
#from sklearn.model_selection import ShuffleSplit
#from sklearn.utils import shuffle
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')

features=traindata.drop(['PATIENT_ID','RE_DATE','age','gender','Admission time','Discharge time','outcome'], axis = 1)
feature_list = list(features.columns)
print(feature_list)

features_train=traindata[:][feature_list]

for col in feature_list:
    replace_val = 0.0
    #replace_val = traindata[col].mean()
    #replace_val = traindata[col].median()
    #replace_val_train = traindata[col].mode().iloc[0]
    features_train[col].fillna(replace_val,inplace=True)

labels = np.array(traindata['outcome'])

X_train, X_test, Y_train, Y_test = train_test_split(features_train,labels,test_size=0.33,random_state=10)
print(len(X_train),len(Y_train))
print(X_train[:10])
print(Y_train[:10])
print(sum(Y_train)/len(Y_train))
print(sum(Y_test)/len(Y_test))
#print(features_train[:10])
#print(X_train[:20]['Red blood cell distribution width '])
#print(X_train[:20][['hemoglobin','Red blood cell distribution width ']])

rf5 = RandomForestClassifier(n_estimators=5)
rf10 = RandomForestClassifier(n_estimators=10)
rf15 = RandomForestClassifier(n_estimators=15)
adaboost = AdaBoostClassifier(n_estimators=100)
xgboost = XGBClassifier(n_jobs=-1)
gboost = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,max_depth=1, random_state=0)
models=[rf5,rf10,rf15,adaboost,xgboost, gboost]

file_names=['RF5','RF10','RF15','AdaBoost','XGBoost','GBoost']
file_to_feature={}
file_to_model={}
for i in range(len(file_names)):
    #file_to_feature[file_names[i]]=[]
    file_to_model[file_names[i]]=models[i]

root=r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\results\all\feature+ model selection1\model_feature\\"
for filename in file_names:
    f_list = []
    file = root + filename+".txt"
    with open(file,'r',encoding='utf-8') as f:
        for line in f:
            f_list.append(line.strip("\n"))
    file_to_feature[filename]=f_list
print(file_to_feature)

'''
def confusion_matrix_scorer(clf, X, y):
    y_pred = clf.predict(X)
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}
'''

def confusion_matrix_scorer(y_pred, y):
    cm = confusion_matrix(y, y_pred)
    return {'tn': cm[0, 0], 'fp': cm[0, 1],'fn': cm[1, 0], 'tp': cm[1, 1]}

with open(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\results\all\train_test1.txt",'a',encoding='utf-8') as file:
    #file.write("feature\tmodel\tprecision_1\trecall_1\tf1_score_1\tprecision_0\trecall_0\tf1_score_0\taccuracy\n")
    file.write("model\tf1_score_1\tf1_score_0\taccuracy\n")
    for model_name in file_names:
        m = file_to_model[model_name]
        print(model_name)
        print(file_to_feature[model_name])
        X_train_select = X_train[:][file_to_feature[model_name]]
        X_test_select = X_test[:][file_to_feature[model_name]]
        model=m.fit(X_train_select,Y_train)
        result=model.predict(X_test_select)
        score = confusion_matrix_scorer(result,Y_test)
        print(score)
        recall_1= score['tp']/(score['fn']+score['tp'])
        precision_1 = score['tp']/(score['fp']+score['tp'])
        f1_1 = 2*recall_1*precision_1/(recall_1+precision_1)
        recall_0= score['tn']/(score['fp']+score['tn'])
        precision_0 = score['tn']/(score['fn']+score['tn'])
        f1_0 = 2*recall_0*precision_0/(recall_0+precision_0)
        acc = (score['tp']+score['tn'])/(score['fn']+score['tp']+score['fp']+score['tn'])
        print("1: "+ str(precision_1)+"\t"+str(recall_1))
        print("0: "+ str(precision_0)+"\t"+str(recall_0))
        print("accuracy\t"+str(acc))
        #file.write(','.join(file_to_feature[model_name])+"\t"+str(m)+"\t"+str(precision_1)+"\t"+str(recall_1)+"\t"+str(f1_1)+"\t"+str(precision_0)+"\t"+str(recall_0)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")
        file.write(model_name+"\t"+str(f1_1)+"\t"+str(f1_0)+"\t"+str(acc)+"\n")
        

