import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import ShuffleSplit
from sklearn.utils import shuffle

traindata=pd.read_excel(r"C:\Users\Jin Xu\Desktop\DM\FINAL PROJECT\time_series_375_preprocess_en.xlsx",sheet_name='Sheet1')
traindata=shuffle(traindata)

#labels = np.array(traindata['outcome'])
labels=traindata[:]['outcome']
labels=labels.values.tolist()
#print(labels)
features= traindata.drop(['PATIENT_ID','RE_DATE','age','gender','Admission time','Discharge time','outcome'], axis = 1)
print(features.shape)

feature_list = list(features.columns)

#cv = ShuffleSplit(n_splits=5, test_size=0.3, random_state=0)

svm_linear = svm.SVC(kernel='linear')
svm_rbf = svm.SVC(kernel='rbf')
svm_poly = svm.SVC(kernel='poly')
svm_sigmoid = svm.SVC(kernel='sigmoid')
models=[svm_linear,svm_rbf,svm_poly,svm_sigmoid]

with open(r"C:\Users\Jin Xu\Desktop\svm_kernel.txt",'a',encoding='utf-8') as file:
    for f in feature_list:
        print(f)
        feature = features[:][[f]]
        feature.fillna(0,inplace=True)
        feature=feature.values.tolist()
        for m in models:
            print(m)
            score=cross_val_score(m,feature,labels,cv=5)
            print(np.mean(score))
            print(np.std(score)*2)
            file.write(f+"\t"+str(m)+"\t"+str(np.mean(score))+"\t"+str(np.std(score)*2)+"\n")
